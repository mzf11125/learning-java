package interfaces;

public interface Reservable {
    void reserveItem();

    void cancelReservation();
}
