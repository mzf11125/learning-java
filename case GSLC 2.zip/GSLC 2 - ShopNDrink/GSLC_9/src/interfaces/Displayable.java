package interfaces;

public interface Displayable {

	public abstract void showDetails();
	
}
