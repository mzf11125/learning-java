package model;

public abstract class Item {
	public abstract void printDetail();
}
