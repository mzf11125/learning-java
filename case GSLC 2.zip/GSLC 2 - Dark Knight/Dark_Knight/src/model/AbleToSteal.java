package model;

public interface AbleToSteal {
	public abstract boolean stealWeapon(Player p);

}
