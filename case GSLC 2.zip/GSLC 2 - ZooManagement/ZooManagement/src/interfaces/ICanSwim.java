package interfaces;

public interface ICanSwim {
	void swim();
}
