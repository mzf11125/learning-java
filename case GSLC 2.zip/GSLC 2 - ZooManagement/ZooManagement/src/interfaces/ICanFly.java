package interfaces;

public interface ICanFly {
	void fly();
}
